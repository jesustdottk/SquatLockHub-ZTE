// Audio Forge Diagnostic App v1.0
var audioCtx = new (window.AudioContext || window.webkitAudioContext)();
var currentOsc = null;
var intervalId = null;

function stopAudio() {
    if (intervalId) clearInterval(intervalId);
    if (currentOsc) {
        currentOsc.stop();
        currentOsc = null;
    }
    document.getElementById('status').innerText = "Stopped";
}

function playTone(freq, duration, type, volume) {
    if (audioCtx.state === 'suspended') audioCtx.resume();
    
    var osc = audioCtx.createOscillator();
    var gain = audioCtx.createGain();
    
    osc.type = type || 'square';
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    
    gain.gain.setValueAtTime(volume || 0.1, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
    
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
}

function playPattern(p) {
    stopAudio();
    var status = document.getElementById('status');
    status.innerText = "Playing: " + p;
    
    switch(p) {
        case 'siren':
            intervalId = setInterval(function() {
                var now = audioCtx.currentTime;
                playTone(440, 0.4, 'sawtooth');
                setTimeout(function(){ playTone(880, 0.4, 'sawtooth'); }, 500);
            }, 1000);
            break;
            
        case 'triple':
            intervalId = setInterval(function() {
                playTone(1000, 0.1, 'square');
                setTimeout(function(){ playTone(1000, 0.1, 'square'); }, 150);
                setTimeout(function(){ playTone(1000, 0.1, 'square'); }, 300);
            }, 1500);
            break;
            
        case 'chirp':
            intervalId = setInterval(function() {
                var osc = audioCtx.createOscillator();
                var gain = audioCtx.createGain();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(100, audioCtx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(2000, audioCtx.currentTime + 0.1);
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.1);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.1);
            }, 300);
            break;

        case 'alarm':
            intervalId = setInterval(function() {
                playTone(880, 0.2, 'square', 0.3);
                setTimeout(function(){ playTone(440, 0.2, 'square', 0.3); }, 250);
            }, 500);
            break;
    }
}
