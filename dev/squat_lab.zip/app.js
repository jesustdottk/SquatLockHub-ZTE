// Squat Lab Telemetry v1.0
var magEl = document.getElementById('magnitude');
var stateEl = document.getElementById('state');
var repsEl = document.getElementById('reps');
var peakEl = document.getElementById('peak');
var dipEl = document.getElementById('dip');

var motionState = 'STILL';
var squatCount = 0;
var peak = 0;
var dip = 20;

function resetStats() {
    squatCount = 0;
    peak = 0;
    dip = 20;
    repsEl.innerText = "REPS: 0";
    peakEl.innerText = "-";
    dipEl.innerText = "-";
}

function onMotion(e) {
    var a = e.accelerationIncludingGravity;
    if (!a || !a.z) return;

    var magnitude = Math.sqrt(a.x*a.x + a.y*a.y + a.z*a.z);
    magEl.innerText = magnitude.toFixed(2);
    
    if (magnitude > peak) {
        peak = magnitude;
        peakEl.innerText = peak.toFixed(2);
    }
    if (magnitude < dip) {
        dip = magnitude;
        dipEl.innerText = dip.toFixed(2);
    }

    // Diagnostic Threshold Logic (Match v2.3 or experiment)
    if (motionState === 'STILL' && magnitude < 8.2) {
        motionState = 'DOWN';
        stateEl.innerText = "DOWN";
        stateEl.style.color = "#ff4141";
    } else if (motionState === 'DOWN' && magnitude > 10.8) {
        motionState = 'UP';
        stateEl.innerText = "UP";
        stateEl.style.color = "#00FF41";
    } else if (motionState === 'UP' && magnitude > 8.5 && magnitude < 11.5) {
        motionState = 'STILL';
        stateEl.innerText = "STILL";
        stateEl.style.color = "#00FF41";
        squatCount++;
        repsEl.innerText = "REPS: " + squatCount;
        if (navigator.vibrate) navigator.vibrate(50);
    }
}

window.addEventListener('devicemotion', onMotion);

// Initialize with some test data if no sensors? No, wait for device.
console.log("Squat Lab Initialized");
